# Temporary Root 2.1.1 - SukiSU Ultra v4.3.0-r2 payload detection

## Changes

- Preserves the legacy `libksud.so` and `ksud` filename paths.
- Adds fallback discovery for exactly one `.so` file larger than 1 MiB that validates as ELF64, little-endian, AArch64 (`EM_AARCH64`), PIE (`ET_DYN`), has a non-zero entry point, and contains an executable `PT_LOAD` segment.
- Uses the same resolver for Manager UI detection and staging, preventing the UI from accepting a payload that the staging path cannot find.
- Refuses ambiguous matches rather than choosing an arbitrary large `.so`.
- Prevents the Run button from being enabled when the selected installed Manager has no compatible payload.
- Does not edit `DirtyFragStrategy.java`, `bootstrap.c`, `exp.c`, or GhostLock sources.

## Build status

This is a patched source tree, not a built APK. The build environment used for this patch did not have network access to fetch Gradle 9.7.1, an Android SDK/NDK installation, or the eight prebuilt `app/src/main/jni/ko/*.ko` files required by this repository's CMake build. Do not treat this ZIP as an installable APK.

## Important validation note

The fallback uses the requested >1 MiB threshold as a filter, not as proof of identity. ELF checks narrow the candidate to an AArch64 PIE executable. If more than one candidate matches, detection intentionally fails closed. The actual v4.3.0-r2 Manager APK was not supplied in this turn, so the exact randomized filename and payload were not independently tested here.
