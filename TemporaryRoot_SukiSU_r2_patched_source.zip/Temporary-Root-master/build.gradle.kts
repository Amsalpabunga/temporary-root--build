plugins {
    id("com.android.application") version "9.4.0" apply false
    id("org.jetbrains.kotlin.jvm") version "2.4.21" apply false
}
